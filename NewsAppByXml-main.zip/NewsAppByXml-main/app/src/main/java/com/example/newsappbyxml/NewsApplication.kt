package com.example.newsappbyxml

import android.app.Application

class NewsApplication : Application()